import json
import os

def generate_content(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
    """
    request_json = request.get_json(silent=True)
    
    if request_json:
        prompt = request_json.get('prompt', '')
        content_type = request_json.get('contentType', 'blog')
        
        response = {
            "status": "success",
            "message": "AI Content Generator is ready",
            "data": {
                "prompt": prompt,
                "contentType": content_type,
                "generatedContent": f"Generated content for: {prompt} (Type: {content_type})"
            }
        }
    else:
        response = {
            "status": "error",
            "message": "No JSON data received"
        }
    
    return json.dumps(response)